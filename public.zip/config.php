<?php
define('ROOT_PATH', realpath(__DIR__ . '/../gestionDeAnimales/')); // Ajustá según dónde esté este archivo
?>
