<?php include $_SERVER['DOCUMENT_ROOT'] . '/routing.php' ?>
<header>
  <?php  
  require PUBLIC_PAGES_COMPONENTS . '/navbar.php';  ?>
</header>