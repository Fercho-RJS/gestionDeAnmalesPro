<?php include $_SERVER['DOCUMENT_ROOT'] . '/routing.php'; ?>

<!-- Bootstrap desde CDN -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<!-- Bootstrap Icons desde CDN -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<!-- Estilos personalizados -->
<link rel="stylesheet" href="<?php echo PUBLIC_STYLES_URL; ?>custom-support.css">
<link rel="stylesheet" href="<?php echo PUBLIC_STYLES_URL; ?>custom-styles.css">
