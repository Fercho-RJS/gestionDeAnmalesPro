<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/routing.php'; ?>

<div id="support" class="support-align"
  style="position: fixed; bottom: 20px; right: 20px; z-index: 3;">
  <a href="mailto:sanfix.informatica@gmail.com?subject=Soporte%20Comunidad%20de%20Animales&body=Hola,%20necesito%20ayuda%20con...">
  <img src="<?php echo PUBLIC_RESOURCES_IMAGES_URL; ?>support.png"
    height="50" class="support-align" alt="Soporte">
</a>
</div>
